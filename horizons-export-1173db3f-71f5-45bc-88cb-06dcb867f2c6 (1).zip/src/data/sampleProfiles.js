
// This file is deprecated. All data is now fetched from Supabase.
export const sampleProfiles = [];
